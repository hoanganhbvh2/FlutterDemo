import React, { useState } from "react";
import { Plus, Trash2, Link2, Unlink, CheckCircle, Clock, BookOpen, AlertCircle, Sparkles, ChevronDown, ChevronUp, BookMarked, HelpCircle, GraduationCap } from "lucide-react";
import { Step, Edge } from "../types";

interface RoadmapCanvasProps {
  nodes: Step[];
  edges: Edge[];
  onUpdateNodePosition: (id: string, x: number, y: number) => void;
  onAddNode: (x: number, y: number) => void;
  onSelectNode: (id: string) => void;
  onConnectNodes: (fromId: string, toId: string) => void;
  onDisconnectNodes: (edgeId: string) => void;
  onDeleteNode: (id: string) => void;
}

export default function RoadmapCanvas({
  nodes,
  edges,
  onUpdateNodePosition,
  onAddNode,
  onSelectNode,
  onConnectNodes,
  onDisconnectNodes,
  onDeleteNode,
}: RoadmapCanvasProps) {
  const [showConnectorForStep, setShowConnectorForStep] = useState<string | null>(null);

  // Sort nodes by order, fallback to ID
  const sortedNodes = [...nodes].sort((a, b) => a.order - b.order);

  // Get completed stats
  const completedCount = nodes.filter((n) => n.status === "Completed").length;
  const inProgressCount = nodes.filter((n) => n.status === "In Progress").length;
  const totalCount = nodes.length;
  const percentCompleted = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

  // Handle adding new step node
  const handleAddNewStep = () => {
    // Generate position parameters or simple offsets (not used visual but good for data)
    onAddNode(0, 0);
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 select-none">
      
      {/* Sub-Header: Progress Metrics & Quick Actions */}
      <div className="bg-white px-4 py-3 border-b border-slate-100 flex flex-col gap-2 shrink-0 z-10 shadow-2xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <BookMarked className="w-4 h-4 text-indigo-600" />
            <span className="text-xs font-black text-slate-800">Tiến trình Khái niệm ({completedCount}/{totalCount})</span>
          </div>
          <button
            onClick={handleAddNewStep}
            className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-bold rounded-lg flex items-center gap-1 shadow-sm transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Thêm khái niệm</span>
          </button>
        </div>

        {/* Beautiful Compact Progress Bar */}
        <div className="space-y-1">
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden flex">
            <div 
              className="h-full bg-emerald-500 rounded-l-full transition-all duration-300" 
              style={{ width: `${percentCompleted}%` }}
            />
            <div 
              className="h-full bg-amber-400 transition-all duration-300" 
              style={{ width: `${totalCount > 0 ? (inProgressCount / totalCount) * 100 : 0}%` }}
            />
          </div>
          <div className="flex justify-between items-center text-[8px] text-slate-400 font-bold">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> Hoàn thành: {percentCompleted}%
            </span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" /> Đang học: {inProgressCount}
            </span>
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-slate-300" /> Chưa học: {totalCount - completedCount - inProgressCount}
            </span>
          </div>
        </div>
      </div>

      {/* Main Roadmap Steps Area */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 pb-24">
        {sortedNodes.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-slate-200 p-6 space-y-3">
            <HelpCircle className="w-10 h-10 text-slate-300 mx-auto" />
            <div>
              <h5 className="font-bold text-slate-800 text-xs">Chưa có khái niệm nào</h5>
              <p className="text-[10px] text-slate-400 max-w-[200px] mx-auto mt-1 leading-relaxed">
                Bài học này đang trống. Hãy nhấp nút phía trên hoặc tự sinh giáo trình bằng AI.
              </p>
            </div>
            <button
              onClick={handleAddNewStep}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold rounded-lg border border-slate-200 transition-colors"
            >
              + Tạo khái niệm đầu tiên
            </button>
          </div>
        ) : (
          <div className="relative pl-4 space-y-4">
            
            {/* Elegant vertical flow trail line */}
            <div className="absolute top-2 bottom-2 left-1.5 w-0.5 bg-slate-200 pointer-events-none" />

            {sortedNodes.map((node, index) => {
              // Find prerequisites of this node (edges where to === node.id)
              const prerequisites = edges.filter((e) => e.to === node.id);
              
              // Get direct steps that can be added as prerequisites (excluding itself and already added ones)
              const availablePrerequisites = nodes.filter(
                (n) => n.id !== node.id && !prerequisites.some((p) => p.from === n.id)
              );

              // Status badges
              const statusPill = {
                "Not Started": { label: "Chưa học", color: "bg-slate-50 text-slate-500 border-slate-200" },
                "In Progress": { label: "Đang học", color: "bg-amber-50 text-amber-700 border-amber-200/50" },
                "Completed": { label: "Đã học", color: "bg-emerald-50 text-emerald-700 border-emerald-200/50" },
              }[node.status];

              return (
                <div 
                  key={node.id} 
                  className="relative group transition-all duration-200"
                >
                  {/* Outer circle marker indicating order on the vertical timeline line */}
                  <div className={`absolute -left-[18.5px] top-4 -translate-x-1/2 w-3 h-3 rounded-full border-2 bg-white transition-all duration-300 z-10 ${
                    node.status === "Completed" 
                      ? "border-emerald-500 bg-emerald-500 shadow-xs shadow-emerald-500/25" 
                      : node.status === "In Progress" 
                      ? "border-amber-400 bg-amber-400" 
                      : "border-slate-300"
                  }`} />

                  {/* Step Card details container */}
                  <div className={`bg-white rounded-2xl border p-3.5 shadow-xs hover:shadow-md transition-all duration-200 space-y-2.5 ${
                    node.status === "Completed" 
                      ? "border-emerald-100 ring-2 ring-emerald-500/5" 
                      : "border-slate-100"
                  }`}>
                    
                    {/* First row: Header & Status & Info actions */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-start gap-2 max-w-[70%]">
                        <span className="text-xl shrink-0 leading-none mt-0.5">{node.emoji || "📝"}</span>
                        <div className="overflow-hidden">
                          <span className="text-[9px] text-indigo-600 font-extrabold uppercase tracking-wider block">
                            Bước {node.order}
                          </span>
                          <h5 className="font-bold text-slate-800 text-xs truncate group-hover:text-indigo-600 transition-colors">
                            {node.title}
                          </h5>
                        </div>
                      </div>

                      {/* Interactive status toggle directly on the list */}
                      <button
                        onClick={() => onSelectNode(node.id)}
                        className={`px-2 py-0.5 border rounded-full text-[9px] font-black cursor-pointer shadow-2xs transition-colors shrink-0 ${statusPill.color}`}
                      >
                        {statusPill.label}
                      </button>
                    </div>

                    {/* Second row: Description paragraph */}
                    <p className="text-[10.5px] text-slate-400 leading-normal line-clamp-2">
                      {node.description || "Chưa bổ sung mô tả bài học."}
                    </p>

                    {/* Third row: Prerequisites & Relationship indicators */}
                    <div className="border-t border-slate-50 pt-2 space-y-2">
                      <div className="flex flex-wrap items-center gap-1.5 min-h-[16px]">
                        <span className="text-[9px] text-slate-400 font-bold uppercase shrink-0">Yêu cầu học trước:</span>
                        
                        {prerequisites.length === 0 ? (
                          <span className="text-[9px] text-slate-400 font-semibold italic">Không có</span>
                        ) : (
                          prerequisites.map((p) => {
                            const preStep = nodes.find((n) => n.id === p.from);
                            if (!preStep) return null;
                            return (
                              <span 
                                key={p.id}
                                className="inline-flex items-center gap-1 bg-slate-50 border border-slate-150 px-2 py-0.5 rounded-md text-[9px] text-slate-600 font-bold"
                              >
                                <span>{preStep.emoji} {preStep.title.split("/")[0]}</span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    onDisconnectNodes(p.id);
                                  }}
                                  className="text-slate-400 hover:text-red-500 hover:bg-slate-200/50 rounded p-0.5 cursor-pointer ml-0.5"
                                  title="Xóa yêu cầu học trước"
                                >
                                  <Unlink className="w-2.5 h-2.5" />
                                </button>
                              </span>
                            );
                          })
                        )}
                      </div>

                      {/* Add Prerequisites dropdown trigger inside smartphone screen */}
                      {availablePrerequisites.length > 0 && (
                        <div className="relative">
                          {showConnectorForStep === node.id ? (
                            <div className="mt-1 bg-slate-50 border border-slate-200 rounded-xl p-2 space-y-1.5">
                              <label className="block text-[8.5px] font-extrabold text-slate-400 uppercase tracking-wide">
                                Đặt điều kiện bài cần học trước:
                              </label>
                              <select
                                onChange={(e) => {
                                  const targetVal = e.target.value;
                                  if (targetVal) {
                                    onConnectNodes(targetVal, node.id);
                                    setShowConnectorForStep(null);
                                  }
                                }}
                                defaultValue=""
                                className="w-full text-[10px] px-2 py-1 bg-white border border-slate-200 rounded-md font-bold text-slate-700 outline-none"
                              >
                                <option value="" disabled>-- Chọn bài học trước --</option>
                                {availablePrerequisites.map((ap) => (
                                  <option key={ap.id} value={ap.id}>
                                    Bước {ap.order}: {ap.emoji} {ap.title.split("/")[0]}
                                  </option>
                                ))}
                              </select>
                              <div className="flex justify-end">
                                <button
                                  onClick={() => setShowConnectorForStep(null)}
                                  className="text-[9px] text-slate-400 font-bold hover:text-slate-600"
                                >
                                  Đóng
                                </button>
                              </div>
                            </div>
                          ) : (
                            <button
                              onClick={() => setShowConnectorForStep(node.id)}
                              className="text-[9px] text-indigo-600 hover:text-indigo-800 font-bold flex items-center gap-1 cursor-pointer"
                            >
                              <Link2 className="w-3 h-3" />
                              <span>+ Thêm liên kết học trước</span>
                            </button>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Fourth row: Details Action & Delete Button */}
                    <div className="flex justify-between items-center border-t border-slate-50 pt-2 shrink-0">
                      <button
                        onClick={() => onSelectNode(node.id)}
                        className="text-[9.5px] text-indigo-600 hover:text-indigo-800 font-black tracking-tight cursor-pointer"
                      >
                        Chi tiết khái niệm & Tài liệu học →
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Bạn muốn xóa bước học "Bước ${node.order}: ${node.title}"?`)) {
                            onDeleteNode(node.id);
                          }
                        }}
                        className="text-slate-300 hover:text-red-500 hover:bg-red-50/50 p-1 rounded-lg transition-colors cursor-pointer"
                        title="Xóa khái niệm"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
